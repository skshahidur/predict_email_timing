#### This package is built for solving the fraud detection challenge for Revolut platform.

1. There are two main methods for decision making process
	- **check_transaction**
	This method takes a transaction ID and returns the decision by the XGBoost solution
	- **check_transaction_json**
	This method takes a raw data in a json format and returns the decision by the XGBoost solution
	
2. Other than the decision making methods, the package also has two other modules
    - **data_processing**
	This module has all the transformers for building the data processing pipeline
	- **helper_functions**
	This module has all the methods for producing the desired output
